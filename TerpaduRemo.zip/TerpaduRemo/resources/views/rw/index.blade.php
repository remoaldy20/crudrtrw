<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RW</title>
</head>
<body>
    <table border="1" >
        <tr>
            <td>No</td>
            <td>Nama RW</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $rw)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$rw->nama_rw}}</td>
            <td>{{$rw->masa_jabatan}}</td>
            <td>{{$rw->no_telp}}</td>
            <td>{{$rw->email}}</td>
            <td>
                <a href="/rw/edit/{{$rw->id}}">Edit</a>
                <a href="/rw/delete/{{$rw->id}}">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
    <a href="/rw/create">Tambah</a>
</body>
</html>