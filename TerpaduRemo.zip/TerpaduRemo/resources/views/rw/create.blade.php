<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <form action="/rw/store" method="post">
        @csrf
        <tr>
            <label for="">Nama RW</label>
            <input type="text" name="nama_rw">
            <br>
            <label for="">Masa Jabatan</label>
            <input type="text" name="masa_jabatan">
            <br>
            <label for="">No Telp</label>
            <input type="text" name="no_telp">
            <br>
            <label for="">Email</label>
            <input type="email" name="email">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html>