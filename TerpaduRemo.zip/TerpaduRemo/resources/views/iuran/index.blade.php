<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IURAN</title>
</head>
<body>
    <table border="1" align="center">
        <tr>
            <td>No</td>
            <td>Tanggal Update</td>
            <td>Nominal</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $iuran)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$iuran->tgl_update}}</td>
            <td>{{$iuran->nominal}}</td>
            <td>
                <a href="/iuran/edit/{{$iuran->id}}">Edit</a>
                <a href="/iuran/delete/{{$iuran->id}}">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
    <center><a href="/iuran/create">Tambah</a></center>
</body>
</html>