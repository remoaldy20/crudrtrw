<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <br>
    <center>
      <form action="/iuran/store" method="post">
        @csrf
        <tr>
            <td>
                <label for="">Tanggal Update</label>
                <input type="date" name="tgl_update">
            </td>
            <td>
                <label for="">Nominal</label>
                <input type="text" name="nominal">
            </td>
            
            <button type=submit> Simpan </button>
        </tr>
    </form>
</center>
</body>
</html>