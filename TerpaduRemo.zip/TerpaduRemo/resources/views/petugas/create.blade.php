<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/petugas/store" method="post">
        @csrf
        <tr>
            <label for="">Nama Petugas</label>
            <input type="text" name="nama_petugas">
            <br>
            <label for="">Email</label>
            <input type="text" name="email">
            <br>
            <label for="">Password</label>
            <input type="password" name="password">
            <br>
            <label for="">No Telp</label>
            <input type="text" name="no_telp">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html>