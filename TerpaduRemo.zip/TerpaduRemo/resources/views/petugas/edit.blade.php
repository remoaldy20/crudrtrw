<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/petugas/update/{{$edit->id}}" method="post">
    @csrf
    @method('PUT')
        <tr>
            <label for="">Nama Petugas</label>
            <input type="text" name="nama_petugas" value="{{$edit->nama_petugas}}">
            <br>
            <label for="">Email</label>
            <input type="text" name="email" value="{{$edit->email}}">
            <br>
            <label for="">Password</label>
            <input type="text" name="password" value="{{$edit->password}}">
            <br>
            <label for="">No Telp</label>
            <input type="text" name="no_telp" value="{{$edit->no_telp}}">
            <br>       
            <button type=submit> Simpan </button>
    
</body>
</html>