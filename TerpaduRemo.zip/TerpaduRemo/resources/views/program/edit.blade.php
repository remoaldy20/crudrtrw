<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/program/update/{{$edit->id}}" method="post">
        @csrf
        @method('PUT')
        <tr>
            <label for="">Kas</label>
            <input type="text" name="kas" value="{{$edit->kas}}">
            <br>
            <label for="">Kebersihan</label>
            <input type="text" name="kebersihan" value="{{$edit->kebersihan}}">
            <br>
            <label for="">Keamanan</label>
            <input type="text" name="keamanan" value="{{$edit->keamanan}}">
            <br>
            <label for="">Kematian</label>
            <input type="text" name="kematian" value="{{$edit->kematian}}">
            <br>
            <label for="">Kegiatan</label>
            <input type="text" name="kegiatan" value="{{$edit->kegiatan}}">
            <br>
            <label for="">Bencana</label>
            <input type="text" name="bencana" value="{{$edit->bencana}}">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html>