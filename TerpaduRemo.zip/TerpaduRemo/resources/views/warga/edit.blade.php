<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/warga/update/{{$edit->id}}" method="post">
    @csrf
    @method('PUT')
        <tr>
            <label for="">NIK</label>
            <input type="number" name="nik" value="{{$edit->nik}}">
            <br>
            <label for="">Nama</label>
            <input type="text" name="nama" value="{{$edit->nama}}">
            <br>
            <label for="">Jenis Kelamin</label>
            <input type="text" name="jenkel" value="{{$edit->jenkel}}">
            <br>
            <label for="">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" value="{{$edit->tanggal_lahir}}">
            <br>
            <label for="">Tempat Lahir</label>
            <input type="type" name="tempat_lahir" value="{{$edit->tempat_lahir}}">
            <br>
            <label for="">Pekerjaan</label>
            <input type="text" name="pekerjaan" value="{{$edit->pekerjaan}}">
            <br>
            <label for="">Penghasilan</label>
            <input type="text" name="penghasilan" value="{{$edit->penghasilan}}">
            <br>
            <label for="">Kota</label>
            <input type="text" name="kota" value="{{$edit->kota}}">
            <br>
            <label for="">Email</label>
            <input type="email" name="email" value="{{$edit->email}}">
            <br>
            <label for="">password</label>
            <input type="password" name="password" value="{{$edit->password}}">
            <br>
            <label for="">Qr Code</label>
            <input type="number" name="qr_code" value="{{$edit->qr_code}}">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html>