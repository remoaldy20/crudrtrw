<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/warga/store" method="post">
        @csrf
        <tr>
            <label for="">NIK</label>
            <input type="number" name="nik">
            <br>
            <label for="">Nama</label>
            <input type="text" name="nama">
            <br>
            <label for="">Jenis Kelamin</label>
            <input type="text" name="jenkel">
            <br>
            <label for="">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir">
            <br>
            <label for="">Tempat Lahir</label>
            <input type="text" name="tempat_lahir">
            <br>
            <label for="">Pekerjaan</label>
            <input type="text" name="pekerjaan">
            <br>
            <label for="">Penghasilan</label>
            <input type="text" name="penghasilan">
            <br>
            <label for="">Kota</label>
            <input type="text" name="kota">
            <br>
            <label for="">Email</label>
            <input type="email" name="email">
            <br>
            <label for="">password</label>
            <input type="password" name="password">
            <br>
            <label for="">Qr Code</label>
            <input type="number" name="qr_code">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html>