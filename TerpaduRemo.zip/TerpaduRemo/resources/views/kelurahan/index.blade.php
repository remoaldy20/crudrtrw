<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelurahan</title>
</head>
<body>
     <table border="1" >
        <tr>
            <td>No</td>
            <td>Nama Kelurahan</td>
            <td>Nama Lurah</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        @foreach ($data as $isi => $kel)
        <tr>
            <td>{{$isi+1}}</td>
            <td>{{$kel->nama_kelurahan}}</td>
            <td>{{$kel->nama_lurah}}</td>
            <td>{{$kel->masa_jabatan}}</td>
            <td>{{$kel->no_telp}}</td>
            <td>{{$kel->email}}</td>
            <td>
                <a href="/kelurahan/edit/{{$kel->id}}">Edit</a>
                <a href="/kelurahan/delete/{{$kel->id}}">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>
    <a href="/kelurahan/create">Tambah</a>
</body>
</html>