<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rw extends Model
{
    protected $table= "rws";
    protected $fillable= [
        'nama_rw',
        'masa_jabatan',
        'no_telp',
        'email'
    ];
    protected $PrimaryKey= "id";
}
