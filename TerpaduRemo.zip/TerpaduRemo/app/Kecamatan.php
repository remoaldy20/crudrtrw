<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kecamatan extends Model
{
    protected $table= "kecamatans";
    protected $fillable= [
        'nama_kecamatan',
        'nama_camat',
        'masa_jabatan',
        'no_telp',
        'email'
    ];
    protected $PrimaryKey= "id";
}
