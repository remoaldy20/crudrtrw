<?php

namespace App\Http\Controllers;

use App\Iuran;
use Illuminate\Http\Request;

class IuranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Iuran::all();
        return view('iuran.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('iuran.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=[
            'tgl_update'=>$request->tgl_update,
            'nominal'=>$request->nominal,
        ];
        Iuran::create($data);
        return redirect('/iuran');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Iuran  $iuran
     * @return \Illuminate\Http\Response
     */
    public function show(Iuran $iuran)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Iuran  $iuran
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Iuran::find($id);
        return view('iuran.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Iuran  $iuran
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $edit = Iuran::find($id);
        $data=[
            'tgl_update'=>$request->tgl_update,
            'nominal'=>$request->nominal,
        ];
        $edit->update($data);
        return redirect('/iuran');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Iuran  $iuran
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $delete = Iuran::delete($id);
        return redirect('/iuran');
    }
}
