<?php

namespace App\Http\Controllers;

use App\Rt;
use Illuminate\Http\Request;

class RtController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = RT::all();
        return view('rt.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('rt.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=[
            'nama_rt'=>$request->nama_rt,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email,
        ];
        Rt::create($data);
        return redirect('/rt');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Rt  $rt
     * @return \Illuminate\Http\Response
     */
    public function show(Rt $rt)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Rt  $rt
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Rt::find($id);
        return view('rt.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Rt  $rt
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,  $id)
    {
        $edit = Rt::find($id);
        $data=[
            'nama_rt'=>$request->nama_rt,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email,
        ];
        $edit->update($data);
        return redirect('/rt');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Rt  $rt
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $delete = Rt::delete($id);
        return redirect('/rt');
    }
}
