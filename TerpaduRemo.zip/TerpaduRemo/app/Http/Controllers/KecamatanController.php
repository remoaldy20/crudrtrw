<?php

namespace App\Http\Controllers;

use App\Kecamatan;
use Illuminate\Http\Request;

class KecamatanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Kecamatan::all();
        return view('kecamatan.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('kecamatan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'nama_kecamatan'=>$request->nama_kecamatan,
            'nama_camat'=>$request->nama_camat,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email
        ];
        Kecamatan::create($data);
        return redirect('/kecamatan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Kecamatan  $kecamatan
     * @return \Illuminate\Http\Response
     */
    public function show(Kecamatan $kecamatan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Kecamatan  $kecamatan
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Kecamatan::find($id);
        return view('kecamatan.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Kecamatan  $kecamatan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $edit = Kecamatan::find($id);
        $data = [
            'nama_kecamatan'=>$request->nama_kecamatan,
            'nama_camat'=>$request->nama_camat,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email
        ];
        $edit->update($data);
        return redirect('/kecamatan');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Kecamatan  $kecamatan
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
         $delete = Kecamatan::delete($id);
        return redirect('/kecamatan');
    }
}
