<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Warga;

class WargaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Warga::all();
        return view('warga.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('warga.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data=[
            'nik'=>$request->nik,
            'nama'=>$request->nama,
            'jenkel'=>$request->jenkel,
            'tempat_lahir'=>$request->tempat_lahir,
            'tanggal_lahir'=>$request->tanggal_lahir,
            'pekerjaan'=>$request->pekerjaan,
            'penghasilan'=>$request->penghasilan,
            'kota'=>$request->kota,
            'email'=>$request->email,
            'password'=>$request->password,
            'qr_code'=>$request->qr_code
        ];
        Warga::create($data);
        return redirect('/warga');
    }

    
    /**
     * Display the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
                $data = Warga::find($id);

        return view('warga.show',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $edit = Warga::find($id);
        return view('warga.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $edit = Warga::find($id);
        $data=[
            'nik'=>$request->nik,
            'nama'=>$request->nama,
            'jenkel'=>$request->jenkel,
            'tempat_lahir'=>$request->tempat_lahir,
            'tanggal_lahir'=>$request->tanggal_lahir,
            'pekerjaan'=>$request->pekerjaan,
            'penghasilan'=>$request->penghasilan,
            'kota'=>$request->kota,
            'email'=>$request->email,
            'password'=>$request->password,
            'qr_code'=>$request->qr_code
        ];
        $edit->update($data);
        return redirect('/warga');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $delete = Warga::delete($id);
        return redirect('/warga');
    }
}
