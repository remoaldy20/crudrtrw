<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Iuran extends Model
{
    protected $table= "iurans";
    protected $fillable= [
        'tgl_update',
        'nominal'
    ];
    protected $PrimaryKey= "id";
}
