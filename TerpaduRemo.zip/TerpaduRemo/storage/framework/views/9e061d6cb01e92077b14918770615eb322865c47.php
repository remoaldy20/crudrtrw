<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/kelurahan/update/<?php echo e($edit->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <tr>
            <label for="">Nama Kelurahan</label>
            <input type="text" name="nama_kelurahan" value="<?php echo e($edit->nama_kelurahan); ?>">
            <br>
            <label for="">Nama Lurah</label>
            <input type="text" name="nama_lurah" value="<?php echo e($edit->nama_lurah); ?>">
            <br>
            <label for="">Masa Jabatan</label>
            <input type="text" name="masa_jabatan" value="<?php echo e($edit->masa_jabatan); ?>">
            <br>
            <label for="">No telp</label>
            <input type="text" name="no_telp" value="<?php echo e($edit->no_telp); ?>">
            <br>    
            <label for="">Email</label>
            <input type="email" name="email" value="<?php echo e($edit->email); ?>">
            <br>   
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/kelurahan/edit.blade.php ENDPATH**/ ?>