<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/iuran/store" method="post">
        <?php echo csrf_field(); ?>
        <tr>
            <label for="">Tanggal Update</label>
            <input type="date" name="tgl_update">
            <br>
            <label for="">Nominal</label>
            <input type="text" name="nominal">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/iuran/create.blade.php ENDPATH**/ ?>