<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>WARGA</title>
</head>
<body>
    <table border="1" >
        <tr>
            <td>No</td>
            <td>NIK</td>
            <td>Nama</td>
            <td>Jenis Kelamin</td>
            <td>Action</td>
            </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $warga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($warga->nik); ?></td>
            <td><?php echo e($warga->nama); ?></td>
            <td><?php echo e($warga->jenkel); ?></td>
            <td>
                <a href="/warga/edit/<?php echo e($warga->id); ?>">Edit</a>
                <a href="/warga/show/<?php echo e($warga->id); ?>">Show</a>
                <a href="/warga/delete/<?php echo e($warga->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/warga/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/warga/index.blade.php ENDPATH**/ ?>