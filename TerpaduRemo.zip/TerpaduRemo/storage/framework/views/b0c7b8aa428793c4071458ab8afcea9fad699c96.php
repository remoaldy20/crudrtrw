<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-datatables/style.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title','Petugas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Datatable</h3>
                <p class="text-subtitle text-muted">We use 'simple-datatables' made by @fiduswriter. You can check the full documentation <a href="https://github.com/fiduswriter/Simple-DataTables/wiki">here</a>.</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Datatable</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                Simple Datatable
            </div>
            <div class="card-body">
                <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-columns"><div class="dataTable-top"><div class="dataTable-dropdown"><select class="dataTable-selector form-select"><option value="5">5</option><option value="10" selected="">10</option><option value="15">15</option><option value="20">20</option><option value="25">25</option></select><label>entries per page</label></div><div class="dataTable-search"><input class="dataTable-input" placeholder="Search..." type="text"></div></div><div class="dataTable-container"><table class="table table-striped dataTable-table" id="table1">
                    <thead>
                        <tr><th data-sortable="" style="width: 14.2169%;"><a href="#" class="dataTable-sorter">Name</a></th><th data-sortable="" style="width: 35.6874%;"><a href="#" class="dataTable-sorter">Email</a></th><th data-sortable="" style="width: 18.6658%;"><a href="#" class="dataTable-sorter">Phone</a></th><th data-sortable="" style="width: 17.5052%;"><a href="#" class="dataTable-sorter">City</a></th><th data-sortable="" style="width: 13.9268%;"><a href="#" class="dataTable-sorter">Status</a></th></tr>
                    </thead>
                    <tbody><tr><td>Graiden</td><td>vehicula.aliquet@semconsequat.co.uk</td><td>076 4820 8838</td><td>Offenburg</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Dale</td><td>fringilla.euismod.enim@quam.ca</td><td>0500 527693</td><td>New Quay</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Nathaniel</td><td>mi.Duis@diam.edu</td><td>(012165) 76278</td><td>Grumo Appula</td><td>
                                <span class="badge bg-danger">Inactive</span>
                            </td></tr><tr><td>Darius</td><td>velit@nec.com</td><td>0309 690 7871</td><td>Ways</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Oleg</td><td>rhoncus.id@Aliquamauctorvelit.net</td><td>0500 441046</td><td>Rossignol</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Kermit</td><td>diam.Sed.diam@anteVivamusnon.org</td><td>(01653) 27844</td><td>Patna</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Jermaine</td><td>sodales@nuncsit.org</td><td>0800 528324</td><td>Mold</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Ferdinand</td><td>gravida.molestie@tinciduntadipiscing.org</td><td>(016977) 4107</td><td>Marlborough</td><td>
                                <span class="badge bg-danger">Inactive</span>
                            </td></tr><tr><td>Kuame</td><td>Quisque.purus@mauris.org</td><td>(0151) 561 8896</td><td>Tresigallo</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr><tr><td>Deacon</td><td>Duis.a.mi@sociisnatoquepenatibus.com</td><td>07740 599321</td><td>Karapınar</td><td>
                                <span class="badge bg-success">Active</span>
                            </td></tr></tbody>
                </table></div><div class="dataTable-bottom"><div class="dataTable-info">Showing 1 to 10 of 26 entries</div><ul class="pagination pagination-primary float-right dataTable-pagination"><li class="page-item pager"><a href="#" class="page-link" data-page="1">‹</a></li><li class="page-item active"><a href="#" class="page-link" data-page="1">1</a></li><li class="page-item"><a href="#" class="page-link" data-page="2">2</a></li><li class="page-item"><a href="#" class="page-link" data-page="3">3</a></li><li class="page-item pager"><a href="#" class="page-link" data-page="2">›</a></li></ul></div></div>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vendors.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
</head>
<body>
     <table border="1" >
        <tr>
            <td>No</td>
            <td>Nama Petugas</td>
            <td>Email</td>
            <td>Password</td>
            <td>No Telp</td>
            <td>Action</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($pet->nama_petugas); ?></td>
            <td><?php echo e($pet->email); ?></td>
            <td><?php echo e($pet->password); ?></td>
            <td><?php echo e($pet->no_telp); ?></td>
            <td>
                <a href="/petugas/edit/<?php echo e($pet->id); ?>">Edit</a>
                <a href="/petugas/delete/<?php echo e($pet->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/petugas/create">Tambah</a>
</body>
</html> -->
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TerpaduRemo\resources\views/petugas/index.blade.php ENDPATH**/ ?>