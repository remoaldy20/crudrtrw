<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RW</title>
</head>
<body>
    <table border="1" >
        <tr>
            <td>No</td>
            <td>Nama RW</td>
            <td>Masa Jabatan</td>
            <td>No Telp</td>
            <td>Email</td>
            <td>Action</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $rw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($rw->nama_rw); ?></td>
            <td><?php echo e($rw->masa_jabatan); ?></td>
            <td><?php echo e($rw->no_telp); ?></td>
            <td><?php echo e($rw->email); ?></td>
            <td>
                <a href="/rw/edit/<?php echo e($rw->id); ?>">Edit</a>
                <a href="/rw/delete/<?php echo e($rw->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/rw/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/rw/index.blade.php ENDPATH**/ ?>