<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/rt/store" method="post">
        <?php echo csrf_field(); ?>
        <tr>
            <label for="">Nama RT</label>
            <input type="text" name="nama_rt">
            <br>
            <label for="">Masa Jabatan</label>
            <input type="text" name="masa_jabatan">
            <br>
            <label for="">No Telp</label>
            <input type="text" name="no_telp">
            <br>
            <label for="">Email</label>
            <input type="email" name="email">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/rt/create.blade.php ENDPATH**/ ?>