<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1 align="center">Create Iuran</h1>
    <center>
      <form action="/iuran/store" method="post">
        <?php echo csrf_field(); ?>
        <tr>
            <td>
                <label for="">Tanggal Update</label>
                <input type="date" name="tgl_update">
            </td>
            <td>
                <label for="">Nominal</label>
                <input type="text" name="nominal">
            </td>
            <br>
            <td>
                <button type=submit> Simpan </button>
            </td>
        </tr>
    </form>
</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\TerpaduRemo\resources\views/iuran/create.blade.php ENDPATH**/ ?>