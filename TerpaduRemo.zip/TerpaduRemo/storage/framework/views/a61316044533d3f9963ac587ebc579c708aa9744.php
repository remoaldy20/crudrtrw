<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/petugas/update/<?php echo e($edit->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <tr>
            <label for="">Nama Petugas</label>
            <input type="text" name="nama_petugas" value="<?php echo e($edit->nama_petugas); ?>">
            <br>
            <label for="">Email</label>
            <input type="text" name="email" value="<?php echo e($edit->email); ?>">
            <br>
            <label for="">Password</label>
            <input type="text" name="password" value="<?php echo e($edit->password); ?>">
            <br>       
            <button type=submit> Simpan </button>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/petugas/edit.blade.php ENDPATH**/ ?>