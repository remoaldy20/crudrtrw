<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/iuran/update/<?php echo e($edit->id); ?>" method="post" align="center">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <br>
        <tr>
            <td>
                <label for="">Tanggal Update</label>
                <input type="date" name="tgl_update" value="<?php echo e($edit->tgl_update); ?>">
            </td>
            <td>
                <label for="">Nominal</label>
                <input type="text" name="nominal" value="<?php echo e($edit->nominal); ?>">
            </td>
                 
            <button type=submit> Simpan </button>
        </tr>
</body>
</html><?php /**PATH C:\xampp\htdocs\TerpaduRemo\resources\views/iuran/edit.blade.php ENDPATH**/ ?>