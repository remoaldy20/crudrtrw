<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/kecamatan/store" method="post" align="center">
        <?php echo csrf_field(); ?>
        <tr>
            <td>
                <label for="">Nama Kecamatan</label>
                <input type="text" name="nama_kecamatan">
            </td>
            <td>
                <label for="">Nama Camat</label>
                <input type="text" name="nama_camat">
            </td>
            <td>
                <label for="">Masa Jabatan</label>
                <input type="text" name="masa_jabatan">
            </td>
            <td>
                <label for="">No telp</label>
                <input type="text" name="no_telp">
            </td>
            <td>
                <label for="">Email</label>
                <input type="email" name="email">
            </td>
            <br>   
            <center><button type=submit> Simpan </button></center> 
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TerpaduRemo\resources\views/kecamatan/create.blade.php ENDPATH**/ ?>