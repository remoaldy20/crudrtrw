<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/program/update/<?php echo e($edit->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <tr>
            <label for="">Kas</label>
            <input type="text" name="kas" value="<?php echo e($edit->kas); ?>">
            <br>
            <label for="">Kebersihan</label>
            <input type="text" name="kebersihan" value="<?php echo e($edit->kebersihan); ?>">
            <br>
            <label for="">Keamanan</label>
            <input type="text" name="keamanan" value="<?php echo e($edit->keamanan); ?>">
            <br>
            <label for="">Kematian</label>
            <input type="text" name="kematian" value="<?php echo e($edit->kematian); ?>">
            <br>
            <label for="">Kegiatan</label>
            <input type="text" name="kegiatan" value="<?php echo e($edit->kegiatan); ?>">
            <br>
            <label for="">Bencana</label>
            <input type="text" name="bencana" value="<?php echo e($edit->bencana); ?>">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/program/edit.blade.php ENDPATH**/ ?>