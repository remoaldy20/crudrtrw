<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IURAN</title>
</head>
<body>
    <table border="1" >
        <tr>
            <td>No</td>
            <td>Tanggal Update</td>
            <td>Nominal</td>
            <td>Action</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $iuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($iuran->tgl_update); ?></td>
            <td><?php echo e($iuran->nominal); ?></td>
            <td>
                <a href="/iuran/edit/<?php echo e($iuran->id); ?>">Edit</a>
                <a href="/iuran/delete/<?php echo e($iuran->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/iuran/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/iuran/index.blade.php ENDPATH**/ ?>