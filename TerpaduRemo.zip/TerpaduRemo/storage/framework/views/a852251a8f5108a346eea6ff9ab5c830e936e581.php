<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <form action="/program/store" method="post">
        <?php echo csrf_field(); ?>
        <tr>
            <label for="">Kas</label>
            <input type="text" name="kas">
            <br>
            <label for="">Kebersihan</label>
            <input type="text" name="kebersihan">
            <br>
            <label for="">Keamanan</label>
            <input type="text" name="keamanan">
            <br>
            <label for="">Kematian</label>
            <input type="text" name="kematian">
            <br>
            <label for="">Kegiatan</label>
            <input type="text" name="kegiatan">
            <br>
            <label for="">Bencana</label>
            <input type="text" name="bencana">
            <br>       
            <button type=submit> Simpan </button>
        </tr>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/program/create.blade.php ENDPATH**/ ?>