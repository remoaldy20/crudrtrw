<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROGRAM</title>
</head>
<body>
     <table border="1" >
        <tr>
            <td>No</td>
            <td>Kas</td>
            <td>Kebersihan</td>
            <td>Keamanan</td>
            <td>Kematian</td>
            <td>Kegiatan</td>
            <td>Bencana</td>
            <td>Action</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($isi+1); ?></td>
            <td><?php echo e($program->kas); ?></td>
            <td><?php echo e($program->kebersihan); ?></td>
            <td><?php echo e($program->keamanan); ?></td>
            <td><?php echo e($program->kematian); ?></td>
            <td><?php echo e($program->kegiatan); ?></td>
            <td><?php echo e($program->bencana); ?></td>
            <td>
                <a href="/program/edit/<?php echo e($program->id); ?>">Edit</a>
                <a href="/program/delete/<?php echo e($program->id); ?>">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/program/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\TERPADU\resources\views/program/index.blade.php ENDPATH**/ ?>